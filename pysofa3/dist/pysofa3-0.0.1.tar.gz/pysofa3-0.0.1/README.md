## Licensing

*pysofa3* not endorsed by the International Astronomical Union. 
In addition to *pysofa3*'s MIT license, any use of this module should comply 
with SOFA's license and [terms of use](http://www.iausofa.org/copyr.pdf). 
Especially, but not exclusively, any published work or commercial products 
which includes results achieved by using *pysofa* shall acknowledge that the 
SOFA software was used in obtaining those results.